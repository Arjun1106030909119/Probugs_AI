document.addEventListener('DOMContentLoaded', async () => {
    const loginView = document.getElementById('login-view');
    const formView = document.getElementById('form-view');
    const successView = document.getElementById('success-view');

    const sourceUrlInput = document.getElementById('source-url');
    const bugTitleInput = document.getElementById('bug-title');
    const severitySelect = document.getElementById('severity');
    const descriptionTextarea = document.getElementById('description');
    const submitBtn = document.getElementById('submit-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const reportAnotherBtn = document.getElementById('report-another-btn');
    const visitBtn = document.getElementById('visit-btn');

    // Login Elements
    const loginEmailInput = document.getElementById('login-email');
    const loginPasswordInput = document.getElementById('login-password');
    const loginBtn = document.getElementById('login-btn');
    const loginError = document.getElementById('login-error');
    const logoutBtn = document.getElementById('logout-btn');
    const userInfoDisplay = document.getElementById('user-info-display');

    let authToken = null;

    // 0. Check Login Status
    chrome.storage.local.get(['token', 'user'], (result) => {
        if (result.token && result.user) {
            authToken = result.token;
            userInfoDisplay.textContent = `LOGGED IN AS ${result.user.name.toUpperCase()}`;
            showView(formView);
        } else {
            showView(loginView);
        }
    });

    function showView(viewToShow) {
        loginView.classList.add('hidden');
        formView.classList.add('hidden');
        successView.classList.add('hidden');
        viewToShow.classList.remove('hidden');
    }

    // 1. Capture current URL
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url) {
            sourceUrlInput.value = tab.url;
        }
    } catch (error) {
        console.error('Error fetching tab URL:', error);
    }

    // 2. Login Logic
    loginBtn.addEventListener('click', async () => {
        const email = loginEmailInput.value;
        const password = loginPasswordInput.value;
        
        if (!email || !password) {
            loginError.textContent = "Email and password required.";
            loginError.classList.remove('hidden');
            return;
        }

        loginBtn.disabled = true;
        loginBtn.textContent = 'Authenticating...';
        loginError.classList.add('hidden');

        try {
            const response = await fetch('https://probugs-backend.onrender.com/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const result = await response.json();
            
            if (response.ok && result.success) {
                authToken = result.token;
                chrome.storage.local.set({ token: authToken, user: result.user });
                userInfoDisplay.textContent = `LOGGED IN AS ${result.user.name.toUpperCase()}`;
                loginEmailInput.value = '';
                loginPasswordInput.value = '';
                showView(formView);
            } else {
                throw new Error(result.error || "Login failed");
            }
        } catch (error) {
            loginError.textContent = error.message;
            loginError.classList.remove('hidden');
        } finally {
            loginBtn.disabled = false;
            loginBtn.textContent = 'Establish Uplink';
        }
    });

    logoutBtn.addEventListener('click', () => {
        authToken = null;
        chrome.storage.local.remove(['token', 'user']);
        showView(loginView);
    });

    // 3. Form Submission
    submitBtn.addEventListener('click', async () => {
        const payload = {
            title: bugTitleInput.value,
            description: descriptionTextarea.value,
            priority: severitySelect.value, // Map to field expected by model
            sourceUrl: sourceUrlInput.value,
            status: 'Open'
        };

        if (!payload.title || !payload.description) {
            alert('Please fill out all fields.');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';

        try {
            const response = await fetch('https://probugs-backend.onrender.com/api/tickets', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${authToken}` // Use real authenticated token
                },
                body: JSON.stringify(payload)
            });

            let result;
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.indexOf("application/json") !== -1) {
                result = await response.json();
            } else {
                const text = await response.text();
                throw new Error(`Server returned non-JSON response: ${text.slice(0, 100)}...`);
            }
            
            if (response.ok && result.success) {
                showSuccessView(result.data.ticketId);
            } else {
                throw new Error(result.error || `Server Error (${response.status}): ${response.statusText}`);
            }
        } catch (error) {
            console.error('Submission error:', error);
            alert('Submission Failed: ' + error.message);
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `Submit Report <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>`;
        }
    });

    // 4. View Transitions
    function showSuccessView(ticketId) {
        document.querySelector('.ticket-id span').textContent = ticketId;
        formView.classList.add('hidden');
        successView.classList.remove('hidden');
    }

    reportAnotherBtn.addEventListener('click', () => {
        bugTitleInput.value = '';
        descriptionTextarea.value = '';
        successView.classList.add('hidden');
        showView(formView);
    });

    // 5. Navigation
    visitBtn.addEventListener('click', (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: 'https://probugs-ai.vercel.app' }); // Vercel Production URL
    });

    cancelBtn.addEventListener('click', () => {
        window.close();
    });
});
